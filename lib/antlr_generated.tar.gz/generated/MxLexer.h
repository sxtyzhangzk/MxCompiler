
// Generated from MxLexer.g4 by ANTLR 4.7

#pragma once


#include "antlr4-runtime.h"




class  MxLexer : public antlr4::Lexer {
public:
  enum {
    BoolType = 1, IntType = 2, StringType = 3, Null = 4, Void = 5, True = 6, 
    False = 7, If = 8, Else = 9, For = 10, While = 11, Break = 12, Continue = 13, 
    Return = 14, New = 15, Class = 16, This = 17, Plus = 18, Minus = 19, 
    Multi = 20, Div = 21, Mod = 22, GreaterThan = 23, LessThan = 24, Equal = 25, 
    NotEqual = 26, GreaterEqual = 27, LessEqual = 28, And = 29, Or = 30, 
    Not = 31, ShiftLeft = 32, ShiftRight = 33, BitNot = 34, BitOr = 35, 
    BitAnd = 36, BitXor = 37, Assign = 38, Increment = 39, Decrement = 40, 
    Dot = 41, OpenPar = 42, ClosePar = 43, OpenSqu = 44, CloseSqu = 45, 
    OpenCurly = 46, CloseCurly = 47, Semicolon = 48, Comma = 49, Id = 50, 
    IntegerDec = 51, String = 52, Comment = 53, CommentBlock = 54, Whitespace = 55
  };

  MxLexer(antlr4::CharStream *input);
  ~MxLexer();

  virtual std::string getGrammarFileName() const override;
  virtual const std::vector<std::string>& getRuleNames() const override;

  virtual const std::vector<std::string>& getChannelNames() const override;
  virtual const std::vector<std::string>& getModeNames() const override;
  virtual const std::vector<std::string>& getTokenNames() const override; // deprecated, use vocabulary instead
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;

  virtual const std::vector<uint16_t> getSerializedATN() const override;
  virtual const antlr4::atn::ATN& getATN() const override;

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;
  static std::vector<std::string> _channelNames;
  static std::vector<std::string> _modeNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  // Individual action functions triggered by action() above.

  // Individual semantic predicate functions triggered by sempred() above.

  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

