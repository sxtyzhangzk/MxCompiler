
// Generated from MxParser.g4 by ANTLR 4.7

#pragma once


#include "antlr4-runtime.h"
#include "MxParser.h"



/**
 * This class defines an abstract visitor for a parse tree
 * produced by MxParser.
 */
class  MxParserVisitor : public antlr4::tree::AbstractParseTreeVisitor {
public:

  /**
   * Visit parse trees produced by MxParser.
   */
    virtual antlrcpp::Any visitExprList(MxParser::ExprListContext *context) = 0;

    virtual antlrcpp::Any visitExprNewDim(MxParser::ExprNewDimContext *context) = 0;

    virtual antlrcpp::Any visitExprPrimary(MxParser::ExprPrimaryContext *context) = 0;

    virtual antlrcpp::Any visitExprPar(MxParser::ExprParContext *context) = 0;

    virtual antlrcpp::Any visitExprMember(MxParser::ExprMemberContext *context) = 0;

    virtual antlrcpp::Any visitExprDecrementPostfix(MxParser::ExprDecrementPostfixContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr0(MxParser::Subexpr0Context *context) = 0;

    virtual antlrcpp::Any visitExprSubscript(MxParser::ExprSubscriptContext *context) = 0;

    virtual antlrcpp::Any visitExprIncrementPostfix(MxParser::ExprIncrementPostfixContext *context) = 0;

    virtual antlrcpp::Any visitExprFuncCall(MxParser::ExprFuncCallContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr1(MxParser::Subexpr1Context *context) = 0;

    virtual antlrcpp::Any visitExprIncrementPrefix(MxParser::ExprIncrementPrefixContext *context) = 0;

    virtual antlrcpp::Any visitExprDecrementPrefix(MxParser::ExprDecrementPrefixContext *context) = 0;

    virtual antlrcpp::Any visitExprPositive(MxParser::ExprPositiveContext *context) = 0;

    virtual antlrcpp::Any visitExprNegative(MxParser::ExprNegativeContext *context) = 0;

    virtual antlrcpp::Any visitExprNot(MxParser::ExprNotContext *context) = 0;

    virtual antlrcpp::Any visitExprBitNot(MxParser::ExprBitNotContext *context) = 0;

    virtual antlrcpp::Any visitExprNew(MxParser::ExprNewContext *context) = 0;

    virtual antlrcpp::Any visitExprDiv(MxParser::ExprDivContext *context) = 0;

    virtual antlrcpp::Any visitExprMulti(MxParser::ExprMultiContext *context) = 0;

    virtual antlrcpp::Any visitExprMod(MxParser::ExprModContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr2(MxParser::Subexpr2Context *context) = 0;

    virtual antlrcpp::Any visitExprPlus(MxParser::ExprPlusContext *context) = 0;

    virtual antlrcpp::Any visitExprMinus(MxParser::ExprMinusContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr3(MxParser::Subexpr3Context *context) = 0;

    virtual antlrcpp::Any visitExprShiftLeft(MxParser::ExprShiftLeftContext *context) = 0;

    virtual antlrcpp::Any visitExprShiftRight(MxParser::ExprShiftRightContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr4(MxParser::Subexpr4Context *context) = 0;

    virtual antlrcpp::Any visitSubexpr5(MxParser::Subexpr5Context *context) = 0;

    virtual antlrcpp::Any visitExprLessThan(MxParser::ExprLessThanContext *context) = 0;

    virtual antlrcpp::Any visitExprGreaterThan(MxParser::ExprGreaterThanContext *context) = 0;

    virtual antlrcpp::Any visitExprLessEqual(MxParser::ExprLessEqualContext *context) = 0;

    virtual antlrcpp::Any visitExprGreaterEqual(MxParser::ExprGreaterEqualContext *context) = 0;

    virtual antlrcpp::Any visitExprNotEqual(MxParser::ExprNotEqualContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr6(MxParser::Subexpr6Context *context) = 0;

    virtual antlrcpp::Any visitExprEqual(MxParser::ExprEqualContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr7(MxParser::Subexpr7Context *context) = 0;

    virtual antlrcpp::Any visitExprBitand(MxParser::ExprBitandContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr8(MxParser::Subexpr8Context *context) = 0;

    virtual antlrcpp::Any visitExprXor(MxParser::ExprXorContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr9(MxParser::Subexpr9Context *context) = 0;

    virtual antlrcpp::Any visitExprBitor(MxParser::ExprBitorContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr10(MxParser::Subexpr10Context *context) = 0;

    virtual antlrcpp::Any visitExprAnd(MxParser::ExprAndContext *context) = 0;

    virtual antlrcpp::Any visitExprOr(MxParser::ExprOrContext *context) = 0;

    virtual antlrcpp::Any visitSubexpr11(MxParser::Subexpr11Context *context) = 0;

    virtual antlrcpp::Any visitSubexpr12(MxParser::Subexpr12Context *context) = 0;

    virtual antlrcpp::Any visitExprAssignment(MxParser::ExprAssignmentContext *context) = 0;

    virtual antlrcpp::Any visitExpr(MxParser::ExprContext *context) = 0;

    virtual antlrcpp::Any visitTypeInternal(MxParser::TypeInternalContext *context) = 0;

    virtual antlrcpp::Any visitTypeNotArray(MxParser::TypeNotArrayContext *context) = 0;

    virtual antlrcpp::Any visitType(MxParser::TypeContext *context) = 0;

    virtual antlrcpp::Any visitVarDecl(MxParser::VarDeclContext *context) = 0;

    virtual antlrcpp::Any visitParamList(MxParser::ParamListContext *context) = 0;

    virtual antlrcpp::Any visitFuncDecl(MxParser::FuncDeclContext *context) = 0;

    virtual antlrcpp::Any visitMemberList(MxParser::MemberListContext *context) = 0;

    virtual antlrcpp::Any visitClassDecl(MxParser::ClassDeclContext *context) = 0;

    virtual antlrcpp::Any visitIf_statement(MxParser::If_statementContext *context) = 0;

    virtual antlrcpp::Any visitFor_exprIn(MxParser::For_exprInContext *context) = 0;

    virtual antlrcpp::Any visitFor_exprCond(MxParser::For_exprCondContext *context) = 0;

    virtual antlrcpp::Any visitFor_exprStep(MxParser::For_exprStepContext *context) = 0;

    virtual antlrcpp::Any visitFor_statement(MxParser::For_statementContext *context) = 0;

    virtual antlrcpp::Any visitWhile_statement(MxParser::While_statementContext *context) = 0;

    virtual antlrcpp::Any visitStatement(MxParser::StatementContext *context) = 0;

    virtual antlrcpp::Any visitBlock(MxParser::BlockContext *context) = 0;

    virtual antlrcpp::Any visitProg(MxParser::ProgContext *context) = 0;


};

