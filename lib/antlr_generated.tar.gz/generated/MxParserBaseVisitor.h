
// Generated from MxParser.g4 by ANTLR 4.7

#pragma once


#include "antlr4-runtime.h"
#include "MxParserVisitor.h"


/**
 * This class provides an empty implementation of MxParserVisitor, which can be
 * extended to create a visitor which only needs to handle a subset of the available methods.
 */
class  MxParserBaseVisitor : public MxParserVisitor {
public:

  virtual antlrcpp::Any visitExprList(MxParser::ExprListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprNewDim(MxParser::ExprNewDimContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprPrimary(MxParser::ExprPrimaryContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprPar(MxParser::ExprParContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprMember(MxParser::ExprMemberContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprDecrementPostfix(MxParser::ExprDecrementPostfixContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr0(MxParser::Subexpr0Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprSubscript(MxParser::ExprSubscriptContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprIncrementPostfix(MxParser::ExprIncrementPostfixContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprFuncCall(MxParser::ExprFuncCallContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr1(MxParser::Subexpr1Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprIncrementPrefix(MxParser::ExprIncrementPrefixContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprDecrementPrefix(MxParser::ExprDecrementPrefixContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprPositive(MxParser::ExprPositiveContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprNegative(MxParser::ExprNegativeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprNot(MxParser::ExprNotContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprBitNot(MxParser::ExprBitNotContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprNew(MxParser::ExprNewContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprDiv(MxParser::ExprDivContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprMulti(MxParser::ExprMultiContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprMod(MxParser::ExprModContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr2(MxParser::Subexpr2Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprPlus(MxParser::ExprPlusContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprMinus(MxParser::ExprMinusContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr3(MxParser::Subexpr3Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprShiftLeft(MxParser::ExprShiftLeftContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprShiftRight(MxParser::ExprShiftRightContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr4(MxParser::Subexpr4Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr5(MxParser::Subexpr5Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprLessThan(MxParser::ExprLessThanContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprGreaterThan(MxParser::ExprGreaterThanContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprLessEqual(MxParser::ExprLessEqualContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprGreaterEqual(MxParser::ExprGreaterEqualContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprNotEqual(MxParser::ExprNotEqualContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr6(MxParser::Subexpr6Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprEqual(MxParser::ExprEqualContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr7(MxParser::Subexpr7Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprBitand(MxParser::ExprBitandContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr8(MxParser::Subexpr8Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprXor(MxParser::ExprXorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr9(MxParser::Subexpr9Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprBitor(MxParser::ExprBitorContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr10(MxParser::Subexpr10Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprAnd(MxParser::ExprAndContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprOr(MxParser::ExprOrContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr11(MxParser::Subexpr11Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitSubexpr12(MxParser::Subexpr12Context *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExprAssignment(MxParser::ExprAssignmentContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitExpr(MxParser::ExprContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeInternal(MxParser::TypeInternalContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitTypeNotArray(MxParser::TypeNotArrayContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitType(MxParser::TypeContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitVarDecl(MxParser::VarDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitParamList(MxParser::ParamListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFuncDecl(MxParser::FuncDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitMemberList(MxParser::MemberListContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitClassDecl(MxParser::ClassDeclContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitIf_statement(MxParser::If_statementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFor_exprIn(MxParser::For_exprInContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFor_exprCond(MxParser::For_exprCondContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFor_exprStep(MxParser::For_exprStepContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitFor_statement(MxParser::For_statementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitWhile_statement(MxParser::While_statementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitStatement(MxParser::StatementContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitBlock(MxParser::BlockContext *ctx) override {
    return visitChildren(ctx);
  }

  virtual antlrcpp::Any visitProg(MxParser::ProgContext *ctx) override {
    return visitChildren(ctx);
  }


};

