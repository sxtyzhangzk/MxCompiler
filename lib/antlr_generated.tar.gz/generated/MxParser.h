
// Generated from MxParser.g4 by ANTLR 4.7

#pragma once


#include "antlr4-runtime.h"




class  MxParser : public antlr4::Parser {
public:
  enum {
    BoolType = 1, IntType = 2, StringType = 3, Null = 4, Void = 5, True = 6, 
    False = 7, If = 8, Else = 9, For = 10, While = 11, Break = 12, Continue = 13, 
    Return = 14, New = 15, Class = 16, This = 17, Plus = 18, Minus = 19, 
    Multi = 20, Div = 21, Mod = 22, GreaterThan = 23, LessThan = 24, Equal = 25, 
    NotEqual = 26, GreaterEqual = 27, LessEqual = 28, And = 29, Or = 30, 
    Not = 31, ShiftLeft = 32, ShiftRight = 33, BitNot = 34, BitOr = 35, 
    BitAnd = 36, BitXor = 37, Assign = 38, Increment = 39, Decrement = 40, 
    Dot = 41, OpenPar = 42, ClosePar = 43, OpenSqu = 44, CloseSqu = 45, 
    OpenCurly = 46, CloseCurly = 47, Semicolon = 48, Comma = 49, Id = 50, 
    IntegerDec = 51, String = 52, Comment = 53, CommentBlock = 54, Whitespace = 55
  };

  enum {
    RuleExprList = 0, RuleExprNewDim = 1, RuleExprPrimary = 2, RuleExprPar = 3, 
    RuleSubexprPostfix = 4, RuleSubexprPrefix = 5, RuleSubexprMultiDiv = 6, 
    RuleSubexprPlusMinus = 7, RuleSubexprShift = 8, RuleSubexprCompareRel = 9, 
    RuleSubexprCompareEqu = 10, RuleSubexprBitand = 11, RuleSubexprXor = 12, 
    RuleSubexprBitor = 13, RuleSubexprAnd = 14, RuleSubexprOr = 15, RuleSubexprAssignment = 16, 
    RuleExpr = 17, RuleTypeInternal = 18, RuleTypeNotArray = 19, RuleType = 20, 
    RuleVarDecl = 21, RuleParamList = 22, RuleFuncDecl = 23, RuleMemberList = 24, 
    RuleClassDecl = 25, RuleIf_statement = 26, RuleFor_exprIn = 27, RuleFor_exprCond = 28, 
    RuleFor_exprStep = 29, RuleFor_statement = 30, RuleWhile_statement = 31, 
    RuleStatement = 32, RuleBlock = 33, RuleProg = 34
  };

  MxParser(antlr4::TokenStream *input);
  ~MxParser();

  virtual std::string getGrammarFileName() const override;
  virtual const antlr4::atn::ATN& getATN() const override { return _atn; };
  virtual const std::vector<std::string>& getTokenNames() const override { return _tokenNames; }; // deprecated: use vocabulary instead.
  virtual const std::vector<std::string>& getRuleNames() const override;
  virtual antlr4::dfa::Vocabulary& getVocabulary() const override;


  class ExprListContext;
  class ExprNewDimContext;
  class ExprPrimaryContext;
  class ExprParContext;
  class SubexprPostfixContext;
  class SubexprPrefixContext;
  class SubexprMultiDivContext;
  class SubexprPlusMinusContext;
  class SubexprShiftContext;
  class SubexprCompareRelContext;
  class SubexprCompareEquContext;
  class SubexprBitandContext;
  class SubexprXorContext;
  class SubexprBitorContext;
  class SubexprAndContext;
  class SubexprOrContext;
  class SubexprAssignmentContext;
  class ExprContext;
  class TypeInternalContext;
  class TypeNotArrayContext;
  class TypeContext;
  class VarDeclContext;
  class ParamListContext;
  class FuncDeclContext;
  class MemberListContext;
  class ClassDeclContext;
  class If_statementContext;
  class For_exprInContext;
  class For_exprCondContext;
  class For_exprStepContext;
  class For_statementContext;
  class While_statementContext;
  class StatementContext;
  class BlockContext;
  class ProgContext; 

  class  ExprListContext : public antlr4::ParserRuleContext {
  public:
    ExprListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    std::vector<antlr4::tree::TerminalNode *> Comma();
    antlr4::tree::TerminalNode* Comma(size_t i);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprListContext* exprList();

  class  ExprNewDimContext : public antlr4::ParserRuleContext {
  public:
    ExprNewDimContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *OpenSqu();
    antlr4::tree::TerminalNode *CloseSqu();
    ExprContext *expr();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprNewDimContext* exprNewDim();

  class  ExprPrimaryContext : public antlr4::ParserRuleContext {
  public:
    ExprPrimaryContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Id();
    antlr4::tree::TerminalNode *String();
    antlr4::tree::TerminalNode *IntegerDec();
    antlr4::tree::TerminalNode *True();
    antlr4::tree::TerminalNode *False();
    antlr4::tree::TerminalNode *This();
    antlr4::tree::TerminalNode *Null();
    ExprParContext *exprPar();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprPrimaryContext* exprPrimary();

  class  ExprParContext : public antlr4::ParserRuleContext {
  public:
    ExprParContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *OpenPar();
    ExprContext *expr();
    antlr4::tree::TerminalNode *ClosePar();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprParContext* exprPar();

  class  SubexprPostfixContext : public antlr4::ParserRuleContext {
  public:
    SubexprPostfixContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprPostfixContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprPostfixContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ExprMemberContext : public SubexprPostfixContext {
  public:
    ExprMemberContext(SubexprPostfixContext *ctx);

    SubexprPostfixContext *subexprPostfix();
    antlr4::tree::TerminalNode *Dot();
    antlr4::tree::TerminalNode *Id();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprDecrementPostfixContext : public SubexprPostfixContext {
  public:
    ExprDecrementPostfixContext(SubexprPostfixContext *ctx);

    SubexprPostfixContext *subexprPostfix();
    antlr4::tree::TerminalNode *Decrement();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  Subexpr0Context : public SubexprPostfixContext {
  public:
    Subexpr0Context(SubexprPostfixContext *ctx);

    ExprPrimaryContext *exprPrimary();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprSubscriptContext : public SubexprPostfixContext {
  public:
    ExprSubscriptContext(SubexprPostfixContext *ctx);

    SubexprPostfixContext *subexprPostfix();
    antlr4::tree::TerminalNode *OpenSqu();
    ExprContext *expr();
    antlr4::tree::TerminalNode *CloseSqu();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprIncrementPostfixContext : public SubexprPostfixContext {
  public:
    ExprIncrementPostfixContext(SubexprPostfixContext *ctx);

    SubexprPostfixContext *subexprPostfix();
    antlr4::tree::TerminalNode *Increment();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprFuncCallContext : public SubexprPostfixContext {
  public:
    ExprFuncCallContext(SubexprPostfixContext *ctx);

    SubexprPostfixContext *subexprPostfix();
    antlr4::tree::TerminalNode *OpenPar();
    ExprListContext *exprList();
    antlr4::tree::TerminalNode *ClosePar();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprPostfixContext* subexprPostfix();
  SubexprPostfixContext* subexprPostfix(int precedence);
  class  SubexprPrefixContext : public antlr4::ParserRuleContext {
  public:
    SubexprPrefixContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprPrefixContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprPrefixContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ExprNewContext : public SubexprPrefixContext {
  public:
    ExprNewContext(SubexprPrefixContext *ctx);

    antlr4::tree::TerminalNode *New();
    TypeNotArrayContext *typeNotArray();
    antlr4::tree::TerminalNode *OpenPar();
    ExprListContext *exprList();
    antlr4::tree::TerminalNode *ClosePar();
    std::vector<ExprNewDimContext *> exprNewDim();
    ExprNewDimContext* exprNewDim(size_t i);
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprNotContext : public SubexprPrefixContext {
  public:
    ExprNotContext(SubexprPrefixContext *ctx);

    antlr4::tree::TerminalNode *Not();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprNegativeContext : public SubexprPrefixContext {
  public:
    ExprNegativeContext(SubexprPrefixContext *ctx);

    antlr4::tree::TerminalNode *Minus();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprDecrementPrefixContext : public SubexprPrefixContext {
  public:
    ExprDecrementPrefixContext(SubexprPrefixContext *ctx);

    antlr4::tree::TerminalNode *Decrement();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  Subexpr1Context : public SubexprPrefixContext {
  public:
    Subexpr1Context(SubexprPrefixContext *ctx);

    SubexprPostfixContext *subexprPostfix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprIncrementPrefixContext : public SubexprPrefixContext {
  public:
    ExprIncrementPrefixContext(SubexprPrefixContext *ctx);

    antlr4::tree::TerminalNode *Increment();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprBitNotContext : public SubexprPrefixContext {
  public:
    ExprBitNotContext(SubexprPrefixContext *ctx);

    antlr4::tree::TerminalNode *BitNot();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprPositiveContext : public SubexprPrefixContext {
  public:
    ExprPositiveContext(SubexprPrefixContext *ctx);

    antlr4::tree::TerminalNode *Plus();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprPrefixContext* subexprPrefix();

  class  SubexprMultiDivContext : public antlr4::ParserRuleContext {
  public:
    SubexprMultiDivContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprMultiDivContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprMultiDivContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ExprDivContext : public SubexprMultiDivContext {
  public:
    ExprDivContext(SubexprMultiDivContext *ctx);

    SubexprMultiDivContext *subexprMultiDiv();
    antlr4::tree::TerminalNode *Div();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprMultiContext : public SubexprMultiDivContext {
  public:
    ExprMultiContext(SubexprMultiDivContext *ctx);

    SubexprMultiDivContext *subexprMultiDiv();
    antlr4::tree::TerminalNode *Multi();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprModContext : public SubexprMultiDivContext {
  public:
    ExprModContext(SubexprMultiDivContext *ctx);

    SubexprMultiDivContext *subexprMultiDiv();
    antlr4::tree::TerminalNode *Mod();
    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  Subexpr2Context : public SubexprMultiDivContext {
  public:
    Subexpr2Context(SubexprMultiDivContext *ctx);

    SubexprPrefixContext *subexprPrefix();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprMultiDivContext* subexprMultiDiv();
  SubexprMultiDivContext* subexprMultiDiv(int precedence);
  class  SubexprPlusMinusContext : public antlr4::ParserRuleContext {
  public:
    SubexprPlusMinusContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprPlusMinusContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprPlusMinusContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ExprPlusContext : public SubexprPlusMinusContext {
  public:
    ExprPlusContext(SubexprPlusMinusContext *ctx);

    SubexprPlusMinusContext *subexprPlusMinus();
    antlr4::tree::TerminalNode *Plus();
    SubexprMultiDivContext *subexprMultiDiv();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprMinusContext : public SubexprPlusMinusContext {
  public:
    ExprMinusContext(SubexprPlusMinusContext *ctx);

    SubexprPlusMinusContext *subexprPlusMinus();
    antlr4::tree::TerminalNode *Minus();
    SubexprMultiDivContext *subexprMultiDiv();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  Subexpr3Context : public SubexprPlusMinusContext {
  public:
    Subexpr3Context(SubexprPlusMinusContext *ctx);

    SubexprMultiDivContext *subexprMultiDiv();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprPlusMinusContext* subexprPlusMinus();
  SubexprPlusMinusContext* subexprPlusMinus(int precedence);
  class  SubexprShiftContext : public antlr4::ParserRuleContext {
  public:
    SubexprShiftContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprShiftContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprShiftContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ExprShiftLeftContext : public SubexprShiftContext {
  public:
    ExprShiftLeftContext(SubexprShiftContext *ctx);

    SubexprShiftContext *subexprShift();
    antlr4::tree::TerminalNode *ShiftLeft();
    SubexprPlusMinusContext *subexprPlusMinus();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprShiftRightContext : public SubexprShiftContext {
  public:
    ExprShiftRightContext(SubexprShiftContext *ctx);

    SubexprShiftContext *subexprShift();
    antlr4::tree::TerminalNode *ShiftRight();
    SubexprPlusMinusContext *subexprPlusMinus();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  Subexpr4Context : public SubexprShiftContext {
  public:
    Subexpr4Context(SubexprShiftContext *ctx);

    SubexprPlusMinusContext *subexprPlusMinus();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprShiftContext* subexprShift();
  SubexprShiftContext* subexprShift(int precedence);
  class  SubexprCompareRelContext : public antlr4::ParserRuleContext {
  public:
    SubexprCompareRelContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprCompareRelContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprCompareRelContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  Subexpr5Context : public SubexprCompareRelContext {
  public:
    Subexpr5Context(SubexprCompareRelContext *ctx);

    SubexprShiftContext *subexprShift();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprLessThanContext : public SubexprCompareRelContext {
  public:
    ExprLessThanContext(SubexprCompareRelContext *ctx);

    SubexprCompareRelContext *subexprCompareRel();
    antlr4::tree::TerminalNode *LessThan();
    SubexprShiftContext *subexprShift();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprGreaterThanContext : public SubexprCompareRelContext {
  public:
    ExprGreaterThanContext(SubexprCompareRelContext *ctx);

    SubexprCompareRelContext *subexprCompareRel();
    antlr4::tree::TerminalNode *GreaterThan();
    SubexprShiftContext *subexprShift();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprLessEqualContext : public SubexprCompareRelContext {
  public:
    ExprLessEqualContext(SubexprCompareRelContext *ctx);

    SubexprCompareRelContext *subexprCompareRel();
    antlr4::tree::TerminalNode *LessEqual();
    SubexprShiftContext *subexprShift();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprGreaterEqualContext : public SubexprCompareRelContext {
  public:
    ExprGreaterEqualContext(SubexprCompareRelContext *ctx);

    SubexprCompareRelContext *subexprCompareRel();
    antlr4::tree::TerminalNode *GreaterEqual();
    SubexprShiftContext *subexprShift();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprCompareRelContext* subexprCompareRel();
  SubexprCompareRelContext* subexprCompareRel(int precedence);
  class  SubexprCompareEquContext : public antlr4::ParserRuleContext {
  public:
    SubexprCompareEquContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprCompareEquContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprCompareEquContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ExprNotEqualContext : public SubexprCompareEquContext {
  public:
    ExprNotEqualContext(SubexprCompareEquContext *ctx);

    SubexprCompareEquContext *subexprCompareEqu();
    antlr4::tree::TerminalNode *NotEqual();
    SubexprCompareRelContext *subexprCompareRel();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  Subexpr6Context : public SubexprCompareEquContext {
  public:
    Subexpr6Context(SubexprCompareEquContext *ctx);

    SubexprCompareRelContext *subexprCompareRel();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprEqualContext : public SubexprCompareEquContext {
  public:
    ExprEqualContext(SubexprCompareEquContext *ctx);

    SubexprCompareEquContext *subexprCompareEqu();
    antlr4::tree::TerminalNode *Equal();
    SubexprCompareRelContext *subexprCompareRel();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprCompareEquContext* subexprCompareEqu();
  SubexprCompareEquContext* subexprCompareEqu(int precedence);
  class  SubexprBitandContext : public antlr4::ParserRuleContext {
  public:
    SubexprBitandContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprBitandContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprBitandContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  Subexpr7Context : public SubexprBitandContext {
  public:
    Subexpr7Context(SubexprBitandContext *ctx);

    SubexprCompareEquContext *subexprCompareEqu();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprBitandContext : public SubexprBitandContext {
  public:
    ExprBitandContext(SubexprBitandContext *ctx);

    SubexprBitandContext *subexprBitand();
    antlr4::tree::TerminalNode *BitAnd();
    SubexprCompareEquContext *subexprCompareEqu();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprBitandContext* subexprBitand();
  SubexprBitandContext* subexprBitand(int precedence);
  class  SubexprXorContext : public antlr4::ParserRuleContext {
  public:
    SubexprXorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprXorContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprXorContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  Subexpr8Context : public SubexprXorContext {
  public:
    Subexpr8Context(SubexprXorContext *ctx);

    SubexprBitandContext *subexprBitand();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprXorContext : public SubexprXorContext {
  public:
    ExprXorContext(SubexprXorContext *ctx);

    SubexprXorContext *subexprXor();
    antlr4::tree::TerminalNode *BitXor();
    SubexprBitandContext *subexprBitand();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprXorContext* subexprXor();
  SubexprXorContext* subexprXor(int precedence);
  class  SubexprBitorContext : public antlr4::ParserRuleContext {
  public:
    SubexprBitorContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprBitorContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprBitorContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  Subexpr9Context : public SubexprBitorContext {
  public:
    Subexpr9Context(SubexprBitorContext *ctx);

    SubexprXorContext *subexprXor();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprBitorContext : public SubexprBitorContext {
  public:
    ExprBitorContext(SubexprBitorContext *ctx);

    SubexprBitorContext *subexprBitor();
    antlr4::tree::TerminalNode *BitOr();
    SubexprXorContext *subexprXor();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprBitorContext* subexprBitor();
  SubexprBitorContext* subexprBitor(int precedence);
  class  SubexprAndContext : public antlr4::ParserRuleContext {
  public:
    SubexprAndContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprAndContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprAndContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  Subexpr10Context : public SubexprAndContext {
  public:
    Subexpr10Context(SubexprAndContext *ctx);

    SubexprBitorContext *subexprBitor();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprAndContext : public SubexprAndContext {
  public:
    ExprAndContext(SubexprAndContext *ctx);

    SubexprAndContext *subexprAnd();
    antlr4::tree::TerminalNode *And();
    SubexprBitorContext *subexprBitor();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprAndContext* subexprAnd();
  SubexprAndContext* subexprAnd(int precedence);
  class  SubexprOrContext : public antlr4::ParserRuleContext {
  public:
    SubexprOrContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprOrContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprOrContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  ExprOrContext : public SubexprOrContext {
  public:
    ExprOrContext(SubexprOrContext *ctx);

    SubexprOrContext *subexprOr();
    antlr4::tree::TerminalNode *Or();
    SubexprAndContext *subexprAnd();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  Subexpr11Context : public SubexprOrContext {
  public:
    Subexpr11Context(SubexprOrContext *ctx);

    SubexprAndContext *subexprAnd();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprOrContext* subexprOr();
  SubexprOrContext* subexprOr(int precedence);
  class  SubexprAssignmentContext : public antlr4::ParserRuleContext {
  public:
    SubexprAssignmentContext(antlr4::ParserRuleContext *parent, size_t invokingState);
   
    SubexprAssignmentContext() : antlr4::ParserRuleContext() { }
    void copyFrom(SubexprAssignmentContext *context);
    using antlr4::ParserRuleContext::copyFrom;

    virtual size_t getRuleIndex() const override;

   
  };

  class  Subexpr12Context : public SubexprAssignmentContext {
  public:
    Subexpr12Context(SubexprAssignmentContext *ctx);

    SubexprOrContext *subexprOr();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  class  ExprAssignmentContext : public SubexprAssignmentContext {
  public:
    ExprAssignmentContext(SubexprAssignmentContext *ctx);

    SubexprOrContext *subexprOr();
    antlr4::tree::TerminalNode *Assign();
    SubexprAssignmentContext *subexprAssignment();
    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
  };

  SubexprAssignmentContext* subexprAssignment();

  class  ExprContext : public antlr4::ParserRuleContext {
  public:
    ExprContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    SubexprAssignmentContext *subexprAssignment();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ExprContext* expr();

  class  TypeInternalContext : public antlr4::ParserRuleContext {
  public:
    TypeInternalContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *IntType();
    antlr4::tree::TerminalNode *StringType();
    antlr4::tree::TerminalNode *BoolType();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeInternalContext* typeInternal();

  class  TypeNotArrayContext : public antlr4::ParserRuleContext {
  public:
    TypeNotArrayContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeInternalContext *typeInternal();
    antlr4::tree::TerminalNode *Id();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeNotArrayContext* typeNotArray();

  class  TypeContext : public antlr4::ParserRuleContext {
  public:
    TypeContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeNotArrayContext *typeNotArray();
    std::vector<antlr4::tree::TerminalNode *> OpenSqu();
    antlr4::tree::TerminalNode* OpenSqu(size_t i);
    std::vector<antlr4::tree::TerminalNode *> CloseSqu();
    antlr4::tree::TerminalNode* CloseSqu(size_t i);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  TypeContext* type();

  class  VarDeclContext : public antlr4::ParserRuleContext {
  public:
    VarDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    TypeContext *type();
    std::vector<antlr4::tree::TerminalNode *> Id();
    antlr4::tree::TerminalNode* Id(size_t i);
    antlr4::tree::TerminalNode *Semicolon();
    std::vector<antlr4::tree::TerminalNode *> Assign();
    antlr4::tree::TerminalNode* Assign(size_t i);
    std::vector<ExprContext *> expr();
    ExprContext* expr(size_t i);
    std::vector<antlr4::tree::TerminalNode *> Comma();
    antlr4::tree::TerminalNode* Comma(size_t i);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  VarDeclContext* varDecl();

  class  ParamListContext : public antlr4::ParserRuleContext {
  public:
    ParamListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<TypeContext *> type();
    TypeContext* type(size_t i);
    std::vector<antlr4::tree::TerminalNode *> Id();
    antlr4::tree::TerminalNode* Id(size_t i);
    std::vector<antlr4::tree::TerminalNode *> Comma();
    antlr4::tree::TerminalNode* Comma(size_t i);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ParamListContext* paramList();

  class  FuncDeclContext : public antlr4::ParserRuleContext {
  public:
    FuncDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Id();
    antlr4::tree::TerminalNode *OpenPar();
    ParamListContext *paramList();
    antlr4::tree::TerminalNode *ClosePar();
    BlockContext *block();
    TypeContext *type();
    antlr4::tree::TerminalNode *Void();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  FuncDeclContext* funcDecl();

  class  MemberListContext : public antlr4::ParserRuleContext {
  public:
    MemberListContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<VarDeclContext *> varDecl();
    VarDeclContext* varDecl(size_t i);
    std::vector<FuncDeclContext *> funcDecl();
    FuncDeclContext* funcDecl(size_t i);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  MemberListContext* memberList();

  class  ClassDeclContext : public antlr4::ParserRuleContext {
  public:
    ClassDeclContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Class();
    antlr4::tree::TerminalNode *Id();
    antlr4::tree::TerminalNode *OpenCurly();
    MemberListContext *memberList();
    antlr4::tree::TerminalNode *CloseCurly();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ClassDeclContext* classDecl();

  class  If_statementContext : public antlr4::ParserRuleContext {
  public:
    If_statementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *If();
    antlr4::tree::TerminalNode *OpenPar();
    ExprContext *expr();
    antlr4::tree::TerminalNode *ClosePar();
    std::vector<StatementContext *> statement();
    StatementContext* statement(size_t i);
    antlr4::tree::TerminalNode *Else();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  If_statementContext* if_statement();

  class  For_exprInContext : public antlr4::ParserRuleContext {
  public:
    For_exprInContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    VarDeclContext *varDecl();
    antlr4::tree::TerminalNode *Semicolon();
    ExprContext *expr();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  For_exprInContext* for_exprIn();

  class  For_exprCondContext : public antlr4::ParserRuleContext {
  public:
    For_exprCondContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *Semicolon();
    ExprContext *expr();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  For_exprCondContext* for_exprCond();

  class  For_exprStepContext : public antlr4::ParserRuleContext {
  public:
    For_exprStepContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    ExprContext *expr();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  For_exprStepContext* for_exprStep();

  class  For_statementContext : public antlr4::ParserRuleContext {
  public:
    For_statementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *For();
    antlr4::tree::TerminalNode *OpenPar();
    For_exprInContext *for_exprIn();
    For_exprCondContext *for_exprCond();
    For_exprStepContext *for_exprStep();
    antlr4::tree::TerminalNode *ClosePar();
    StatementContext *statement();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  For_statementContext* for_statement();

  class  While_statementContext : public antlr4::ParserRuleContext {
  public:
    While_statementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *While();
    antlr4::tree::TerminalNode *OpenPar();
    ExprContext *expr();
    antlr4::tree::TerminalNode *ClosePar();
    StatementContext *statement();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  While_statementContext* while_statement();

  class  StatementContext : public antlr4::ParserRuleContext {
  public:
    StatementContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    BlockContext *block();
    If_statementContext *if_statement();
    For_statementContext *for_statement();
    While_statementContext *while_statement();
    VarDeclContext *varDecl();
    antlr4::tree::TerminalNode *Semicolon();
    ExprContext *expr();
    antlr4::tree::TerminalNode *Continue();
    antlr4::tree::TerminalNode *Break();
    antlr4::tree::TerminalNode *Return();

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  StatementContext* statement();

  class  BlockContext : public antlr4::ParserRuleContext {
  public:
    BlockContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    antlr4::tree::TerminalNode *OpenCurly();
    antlr4::tree::TerminalNode *CloseCurly();
    std::vector<StatementContext *> statement();
    StatementContext* statement(size_t i);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  BlockContext* block();

  class  ProgContext : public antlr4::ParserRuleContext {
  public:
    ProgContext(antlr4::ParserRuleContext *parent, size_t invokingState);
    virtual size_t getRuleIndex() const override;
    std::vector<ClassDeclContext *> classDecl();
    ClassDeclContext* classDecl(size_t i);
    std::vector<FuncDeclContext *> funcDecl();
    FuncDeclContext* funcDecl(size_t i);
    std::vector<VarDeclContext *> varDecl();
    VarDeclContext* varDecl(size_t i);

    virtual antlrcpp::Any accept(antlr4::tree::ParseTreeVisitor *visitor) override;
   
  };

  ProgContext* prog();


  virtual bool sempred(antlr4::RuleContext *_localctx, size_t ruleIndex, size_t predicateIndex) override;
  bool subexprPostfixSempred(SubexprPostfixContext *_localctx, size_t predicateIndex);
  bool subexprMultiDivSempred(SubexprMultiDivContext *_localctx, size_t predicateIndex);
  bool subexprPlusMinusSempred(SubexprPlusMinusContext *_localctx, size_t predicateIndex);
  bool subexprShiftSempred(SubexprShiftContext *_localctx, size_t predicateIndex);
  bool subexprCompareRelSempred(SubexprCompareRelContext *_localctx, size_t predicateIndex);
  bool subexprCompareEquSempred(SubexprCompareEquContext *_localctx, size_t predicateIndex);
  bool subexprBitandSempred(SubexprBitandContext *_localctx, size_t predicateIndex);
  bool subexprXorSempred(SubexprXorContext *_localctx, size_t predicateIndex);
  bool subexprBitorSempred(SubexprBitorContext *_localctx, size_t predicateIndex);
  bool subexprAndSempred(SubexprAndContext *_localctx, size_t predicateIndex);
  bool subexprOrSempred(SubexprOrContext *_localctx, size_t predicateIndex);

private:
  static std::vector<antlr4::dfa::DFA> _decisionToDFA;
  static antlr4::atn::PredictionContextCache _sharedContextCache;
  static std::vector<std::string> _ruleNames;
  static std::vector<std::string> _tokenNames;

  static std::vector<std::string> _literalNames;
  static std::vector<std::string> _symbolicNames;
  static antlr4::dfa::Vocabulary _vocabulary;
  static antlr4::atn::ATN _atn;
  static std::vector<uint16_t> _serializedATN;


  struct Initializer {
    Initializer();
  };
  static Initializer _init;
};

